CREATE TABLE health_center_planline_call (
   planline_call_id
                     SERIAL      NOT NULL
                                 PRIMARY KEY,
    
   planline_call_client
                     TEXT,
    
   planline_call_rev_score
                     INTEGER,
    
   planline_call_helpline_operator
                     TEXT,
    
   planline_call_temp_client_name
                     TEXT,
    
   planline_call_question_record_number
                     INTEGER,
    
   planline_call_question_online_intake
                     INTEGER,
    
   planline_call_consumer_first_name
                     TEXT,
    
   planline_call_consumer_middle_name
                     TEXT,
    
   planline_call_consumer_last_name
                     TEXT,

   planline_call_planline_id
                     INTEGER,
    
   planline_call_larc
                     BOOLEAN,
    
   planline_call_date_of_birth
                     DATE,
    
/*   planline_call_age
                     INTEGER, */ -- Unnecessary. Calculate from DoB.
    
   planline_call_race
                     TEXT,
    
   planline_call_ethnicity
                     TEXT,
    
   planline_call_address
                     TEXT,
    
   planline_call_apartment_name
                     TEXT,
    
   planline_call_city
                     TEXT,
    
   planline_call_state
                     TEXT,
    
   planline_call_zip
                     INTEGER,
    
   planline_call_hsi
                     BOOLEAN,
    
   planline_call_phone_home
                     TEXT,
    
   planline_call_phone_message
                     TEXT,
    
   planline_call_phone_message_person
                     TEXT,
    
   planline_call_phone_work
                     TEXT,
    
   planline_call_phone_other
                     TEXT,
    
   planline_call_marital_status
                     TEXT,
    
   planline_call_language
                     TEXT,
    
   planline_call_highest_grade
                     TEXT,
    
   planline_call_school_location
                     TEXT,
    
   planline_call_employment_status
                     TEXT,
    
   planline_call_number_family_members
                     INTEGER,
    
   planline_call_monthly_income
                     TEXT,
    
   planline_call_insurance_type
                     TEXT,
    
   planline_call_new_or_paying
                     TEXT,
    
   planline_call_osdh_or_free
                     TEXT,
    
   planline_call_hipaa
                     BOOLEAN,
    
   planline_call_appointment_detail
                     TEXT,
    
   planline_call_using_birth_control
                     BOOLEAN,
    
   planline_call_birth_control_source
                     TEXT,
    
   planline_call_birth_control_type
                     TEXT,
    
   planline_call_has_used_birth_control
                     BOOLEAN,
    
   planline_call_desired_method
                     TEXT,
    
   planline_call_appointment_urgency
                     TEXT,
    
   planline_call_date_of_last_period
                     DATE,
    
   planline_call_might_be_pregnant
                     BOOLEAN,
    
   planline_call_has_had_pregnancy_test
                     BOOLEAN,
    
   planline_call_number_previous_pregnancies
                     INTEGER,
    
   planline_call_number_live_births
                     INTEGER,
    
   planline_call_number_abortions
                     INTEGER,
    
   planline_call_number_miscarriages
                     INTEGER,
    
   planline_call_date_of_last_live_birth
                     DATE,
    
   planline_call_symptom_pain
                     BOOLEAN,
    
   planline_call_symptom_fever
                     BOOLEAN,
    
   planline_call_symptom_bleeding
                     BOOLEAN,
    
   planline_call_symptom_discharge
                     BOOLEAN,
    
   planline_call_symptom_sex
                     BOOLEAN,
    
   planline_call_symptom_burning
                     BOOLEAN,
    
   planline_call_appointment_date
                     DATE,
    
   planline_call_appointment_clinic
                     TEXT,
    
   planline_call_appointment_time
                     TIME,
    
   planline_call_can_call
                     BOOLEAN,
    
   planline_call_speak_with
                     TEXT,
    
   planline_call_can_mail
                     BOOLEAN,
    
   planline_call_final_comments
                     TEXT
    
);

CREATE TABLE health_center_babyline_call (
   babyline_call_id
                     SERIAL      NOT NULL
                                 PRIMARY KEY,

   babyline_call_client
                     TEXT,
    
   babyline_call_rev_score
                     INTEGER,
    
   babyline_call_date
                     DATE,
    
   babyline_call_helpline_operator
                     TEXT,
    
   babyline_call_question_risk_level
                     TEXT,
    
   babyline_call_date_of_call
                     DATE,
    
   babyline_call_question_record_number
                     INTEGER,
    
   babyline_call_online_intake
                     TEXT,
    
   babyline_call_appointment_date
                     DATE,
    
   babyline_call_appointment_clinic
                     TEXT,
    
   babyline_call_appointment_time
                     TIME,
    
   babyline_call_appointment_kept
                     BOOLEAN,
    
   babyline_call_confidentiality
                     BOOLEAN,
    
   babyline_call_call_type
                     TEXT,
    
   babyline_call_pregnancy_test_location
                     TEXT,
    
   babyline_call_consumer_first_name
                     TEXT,
    
   babyline_call_consumer_last_name
                     TEXT,
    
   babyline_call_date_of_birth
                     DATE,
    
/*   babyline_call_age
                     INTEGER, */ -- Unnecessary. Compute from DoB.
    
   babyline_call_race
                     TEXT,
    
   babyline_call_ethnicity
                     TEXT,
    
   babyline_call_address
                     TEXT,
    
   babyline_call_apartment_name
                     TEXT,
    
   babyline_call_city
                     TEXT,
    
   babyline_call_state
                     TEXT,
    
   babyline_call_zip
                     INTEGER,
    
   babyline_call_county
                     TEXT,
    
   babyline_call_homeless_shelter
                     BOOLEAN,
    
   babyline_call_hsi
                     BOOLEAN,
    
   babyline_call_phone_home
                     TEXT,
    
   babyline_call_phone_message
                     TEXT,
    
   babyline_call_phone_message_person
                     TEXT,
    
   babyline_call_phone_work
                     TEXT,
    
   babyline_call_phone_other
                     TEXT,
    
   babyline_call_marital_status
                     TEXT,
    
   babyline_call_employment
                     TEXT,
    
   babyline_call_language
                     TEXT,
    
   babyline_call_highest_grade
                     TEXT,
    
   babyline_call_current_grade
                     TEXT,
    
   babyline_call_school
                     TEXT,
    
   babyline_call_using_birth_control
                     BOOLEAN,
    
   babyline_call_birth_control_type
                     TEXT,
    
   babyline_call_pregnancy_attempted
                     BOOLEAN,
    
   babyline_call_date_of_last_period
                     DATE,
    
   babyline_call_due_date
                     DATE,
    
   babyline_call_gestation
                     INTEGER,
    
   babyline_call_number_previous_pregnancies
                     INTEGER,
    
   babyline_call_number_live_births
                     INTEGER,
    
   babyline_call_number_miscarriages
                     INTEGER,
    
   babyline_call_number_abortions
                     INTEGER,
    
   babyline_call_number_stillbirths
                     INTEGER,
    
   babyline_call_number_tubal_pregnancies
                     INTEGER,
    
/*   babyline_call_previous_c_section
                     BOOLEAN, */ -- Unnecessary due to next question
    
   babyline_call_number_c_sections
                     INTEGER,
    
   babyline_call_previous_birth_outcome
                     TEXT,
    
   babyline_call_date_of_last_birth
                     DATE,
    
   babyline_call_previous_postpartum_care
                     BOOLEAN,
    
   babyline_call_postpartum_care_location
                     TEXT,
    
   babyline_call_problems_bleeding
                     BOOLEAN,
    
   babyline_call_problems_headache
                     BOOLEAN,
    
   babyline_call_problems_swelling
                     BOOLEAN,
    
   babyline_call_problems_cramping
                     BOOLEAN,
    
   babyline_call_problems_vomiting
                     BOOLEAN,
    
   babyline_call_problems_uti
                     BOOLEAN,
    
   babyline_call_problems_discharge
                     BOOLEAN,
    
   babyline_call_problems_other_physical
                     TEXT,
    
   babyline_call_problems_number_cigarettes
                     INTEGER,
    
   babyline_call_problems_number_drinks
                     INTEGER,
    
   babyline_call_problems_hit
                     BOOLEAN,
    
   babyline_call_problems_in_unsafe_relationship
                     BOOLEAN,
    
   babyline_call_problems_unsafe_previous_partner
                     BOOLEAN,
    
   babyline_call_problems_diabetes
                     BOOLEAN,
    
   babyline_call_problems_heart_lung_disease
                     BOOLEAN,
    
   babyline_call_problems_seizures
                     BOOLEAN,
    
   babyline_call_problems_thyroid
                     BOOLEAN,
    
   babyline_call_problems_high_bp
                     BOOLEAN,
    
   babyline_call_problems_other_medical
                     TEXT,
    
   babyline_call_problems_had_depression
                     BOOLEAN,
    
   babyline_call_problems_current_depression
                     BOOLEAN,
    
   babyline_call_problems_had_psychiatric_diagnosis
                     BOOLEAN,
    
   babyline_call_problems_psychiatric_diagnosis
                     TEXT,
    
   babyline_call_taking_prescription
                     BOOLEAN,
    
   babyline_call_prescription
                     TEXT,
    
   babyline_call_taking_over_the_counter
                     BOOLEAN,
    
   babyline_call_over_the_counter
                     TEXT,
    
   babyline_call_prenatal_care
                     BOOLEAN,
    
   babyline_call_prenatal_care_location
                     TEXT,
    
   babyline_call_number_family_members
                     INTEGER,
    
   babyline_call_monthly_income
                     TEXT,
    
   babyline_call_non_citizen_or_resident
                     BOOLEAN,
    
   babyline_call_insurance
                     TEXT,
    
   babyline_call_referral_dvis
                     BOOLEAN,
    
   babyline_call_referral_xix_advisor
                     BOOLEAN,
    
   babyline_call_referral_wic
                     BOOLEAN,
    
   babyline_call_referral_transport
                     BOOLEAN,
    
   babyline_call_referral_children_first
                     BOOLEAN,
    
   babyline_call_referral_comm_staff
                     BOOLEAN,
    
/*   babyline_call_referral_other
                     BOOLEAN, */ -- Unnecessary due to next question
    
   babyline_call_referral_which_other
                     TEXT,
    
   babyline_call_can_call
                     BOOLEAN,
    
   babyline_call_can_mail
                     BOOLEAN,
    
   babyline_call_can_send_worker
                     BOOLEAN,
    
   babyline_call_accepted_healthy_start
                     BOOLEAN,
    
   babyline_call_accepted_children_first
                     BOOLEAN,
    
   babyline_call_final_comments
                     TEXT
);